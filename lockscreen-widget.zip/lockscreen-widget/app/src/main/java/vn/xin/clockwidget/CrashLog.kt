package vn.xin.clockwidget

import android.content.Context
import android.util.Log

/** Lỗi đã bắt được chỉ ghi vào logcat; app không hiện, không lưu thông tin lỗi cho người dùng. */
object CrashLog {
    @Suppress("UNUSED_PARAMETER")
    fun record(c: Context, e: Throwable, where: String) {
        Log.w("ClockWidget", where, e)
    }
}
