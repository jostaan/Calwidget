package vn.xin.clockwidget

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            // Dọn các khóa của bản có phần chẩn đoán (1.3) để không còn dữ liệu rác trong cài đặt.
            val sp = Prefs.sp(this)
            val ed = sp.edit()
            var dirty = false
            for (k in sp.all.keys) {
                if (k.startsWith("inflight_") || k == "safeDraw" || k == "previewOff" || k == "deathNote" ||
                    k == "lastCrash" || k == "lastErr" || k == "showExtra" || k == "clockSp" || k == "infoSp" || k == "align"
                ) {
                    ed.remove(k)
                    dirty = true
                }
            }
            if (dirty) ed.apply()
        } catch (t: Throwable) {
            CrashLog.record(this, t, "App.cleanup")
        }
    }
}
