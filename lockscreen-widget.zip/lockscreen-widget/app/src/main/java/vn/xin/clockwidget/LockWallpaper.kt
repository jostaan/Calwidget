package vn.xin.clockwidget

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Ảnh nền màn hình khóa tự vẽ: nền (ảnh người dùng chọn hoặc màu) cộng khối thông tin (thời tiết, ngày, âm lịch, hoàng đạo).
 * Đặt bằng WallpaperManager.setBitmap với cờ FLAG_LOCK, tức API chuẩn của Android, không phải widget.
 * Giờ không nằm trong ảnh (ảnh tĩnh sẽ sai giờ): giờ do đồng hồ của màn hình khóa hệ thống hiển thị.
 * Ảnh chỉ đặt lại khi nội dung đổi (thời tiết, ngày) hoặc khi chỉnh cài đặt.
 */
object LockWallpaper {
    private const val BG_FILE = "lock_bg.jpg"
    private const val BLOCK_W = 0.90f

    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    @Synchronized
    private fun worker(): Handler {
        var h = handler
        if (h == null) {
            val t = HandlerThread("lockwp")
            t.start()
            h = Handler(t.looper)
            thread = t
            handler = h
        }
        return h
    }

    /** Kích thước màn hình theo chiều dọc (rộng, cao) tính bằng pixel. */
    private fun screen(c: Context): Pair<Int, Int> {
        val b = c.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        return Pair(Math.min(b.width(), b.height()), Math.max(b.width(), b.height()))
    }

    private fun bgFile(c: Context) = File(c.filesDir, BG_FILE)

    fun clearBackground(c: Context) {
        bgFile(c).delete()
        Prefs.putStr(c, Prefs.WP_SIG, "")
    }

    /** Đọc ảnh người dùng chọn, cắt giữa cho đúng tỉ lệ màn hình và lưu vào bộ nhớ riêng của app. */
    fun setBackground(c: Context, uri: Uri): Boolean {
        return try {
            val (w, h) = screen(c)
            val src = ImageDecoder.createSource(c.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                var sample = 1
                while (info.size.width / (sample * 2) >= w && info.size.height / (sample * 2) >= h) sample *= 2
                dec.setTargetSampleSize(sample)
            }
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val scale = Math.max(w / bmp.width.toFloat(), h / bmp.height.toFloat())
            val m = Matrix()
            m.setScale(scale, scale)
            m.postTranslate((w - bmp.width * scale) / 2f, (h - bmp.height * scale) / 2f)
            Canvas(out).drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
            FileOutputStream(bgFile(c)).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bmp.recycle()
            out.recycle()
            Prefs.putStr(c, Prefs.WP_SIG, "")
            true
        } catch (t: Throwable) {
            CrashLog.record(c, t, "wallpaper/setBackground")
            false
        }
    }

    private fun darken(color: Int, f: Float): Int =
        android.graphics.Color.rgb(
            (android.graphics.Color.red(color) * f).toInt(),
            (android.graphics.Color.green(color) * f).toInt(),
            (android.graphics.Color.blue(color) * f).toInt()
        )

    private fun drawBackground(c: Context, canvas: Canvas, w: Int, h: Int) {
        val f = bgFile(c)
        if (f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            if (bmp != null) {
                canvas.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
                bmp.recycle()
                return
            }
        }
        val c1 = Prefs.int(c, Prefs.WP_COLOR, 0xFF182848.toInt()) or 0xFF000000.toInt()
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, w * 0.7f, h.toFloat(), c1, darken(c1, 0.45f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    private fun drawBlock(c: Context, canvas: Canvas, w: Int, h: Int) {
        val density = c.resources.displayMetrics.density
        val wPx = (w * BLOCK_W).toInt()
        val rv = Renderer.wallpaperViews(c, wPx / density)
        val v = rv.apply(c, FrameLayout(c))
        v.measure(
            View.MeasureSpec.makeMeasureSpec(wPx, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val vh = v.measuredHeight
        v.layout(0, 0, wPx, vh)

        val pad = 14 * density
        val x = (w - wPx) / 2f
        val y = Math.min(h * Prefs.wpY(c) / 100f, h - vh - pad - 8 * density)

        val bg = Prefs.bgColor(c)
        val scrim = Paint(Paint.ANTI_ALIAS_FLAG)
        scrim.color = android.graphics.Color.argb(
            (Prefs.bgAlpha(c) * 255 / 100).coerceIn(0, 255),
            android.graphics.Color.red(bg), android.graphics.Color.green(bg), android.graphics.Color.blue(bg)
        )
        val r = 22 * density
        canvas.drawRoundRect(x - pad, y - pad, x + wPx + pad, y + vh + pad, r, r, scrim)

        canvas.save()
        canvas.translate(x, y)
        v.draw(canvas)
        canvas.restore()
    }

    /** scale < 1: ảnh thu nhỏ cho bản xem trước. */
    private fun render(c: Context, scale: Float): Bitmap {
        val (w, h) = screen(c)
        val bmp = Bitmap.createBitmap(Math.max(1, (w * scale).toInt()), Math.max(1, (h * scale).toInt()), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.scale(scale, scale)
        drawBackground(c, canvas, w, h)
        drawBlock(c, canvas, w, h)
        return bmp
    }

    /** Dấu nhận biết "nội dung và cài đặt đã đặt lên ảnh": giống nhau thì không đặt lại. */
    private fun signature(c: Context): String {
        val (w, h) = screen(c)
        val parts = ArrayList<String>(Renderer.plainLines(c))
        parts.add(
            listOf(
                Prefs.font(c), Prefs.textColor(c), Prefs.bgColor(c), Prefs.bgAlpha(c), Prefs.int(c, Prefs.WP_COLOR, 0),
                Prefs.wpY(c), bgFile(c).lastModified(), w, h, c.resources.configuration.fontScale
            ).joinToString("#")
        )
        return parts.joinToString("|").hashCode().toString()
    }

    private fun apply(c: Context, force: Boolean): Boolean {
        val sig = signature(c)
        if (!force && sig == Prefs.str(c, Prefs.WP_SIG, "")) return true
        val wm = WallpaperManager.getInstance(c)
        if (!wm.isWallpaperSupported || !wm.isSetWallpaperAllowed) return false
        val bmp = render(c, 1f)
        try {
            wm.setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
            Prefs.sp(c).edit().putString(Prefs.WP_SIG, sig).commit()
        } finally {
            bmp.recycle()
        }
        return true
    }

    /**
     * Vẽ lại và đặt ảnh nền khóa nếu đang bật (hoặc force). Làm ở luồng riêng có Looper (dựng View cần Looper).
     * Gọi từ luồng chính thì không chờ; gọi từ luồng nền thì chờ xong (tối đa 30 giây) để receiver/job không kết thúc sớm.
     * Trả về kết quả khi có chờ; từ luồng chính luôn trả true.
     */
    fun update(ctx: Context, force: Boolean = false): Boolean {
        if (!force && !Prefs.lockWallpaper(ctx)) return true
        val c = ctx.applicationContext
        var ok = false
        val latch = CountDownLatch(1)
        worker().post {
            try {
                ok = apply(c, force)
            } catch (t: Throwable) {
                CrashLog.record(c, t, "wallpaper/apply")
            } finally {
                latch.countDown()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) return true
        latch.await(30, TimeUnit.SECONDS)
        return ok
    }

    /** Bản xem trước thu nhỏ (null nếu lỗi). Gọi lại callback ở luồng nền. */
    fun previewAsync(ctx: Context, cb: (Bitmap?) -> Unit) {
        val c = ctx.applicationContext
        worker().post {
            try {
                cb(render(c, 0.25f))
            } catch (t: Throwable) {
                CrashLog.record(c, t, "wallpaper/preview")
                cb(null)
            }
        }
    }
}
