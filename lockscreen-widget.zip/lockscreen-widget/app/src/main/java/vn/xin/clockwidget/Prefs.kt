package vn.xin.clockwidget

import android.content.Context

object Prefs {
    const val FONT = "font"
    const val TEXT_COLOR = "textColor"
    const val BG_COLOR = "bgColor"
    const val BG_ALPHA = "bgAlpha"
    const val SHOW_LUNAR = "showLunar"
    const val LUNAR_DETAIL = "lunarDetail"
    const val SHOW_CAL = "showCal"
    const val CAL_GOOGLE_ONLY = "calGoogleOnly"
    const val CAL_HOLIDAYS = "calHolidays"
    const val CAL_JSON = "calJson"
    const val CAL_TIME = "calTime"
    const val WD_STYLE = "wdStyle"
    const val REFRESHING_AT = "refreshingAt"
    const val SHOW_WEATHER = "showWeather"
    const val LOCK_CARD = "lockCard"
    const val LOCK_STYLE = "lockStyle"
    const val LOCK_COLOR = "lockColor"
    const val LOC_NAME = "locName"
    const val LAT = "lat"
    const val LON = "lon"
    const val W_JSON = "wJson"
    const val W_TIME = "wTime"
    const val W_AQI = "wAqi"
    const val LAST_ERR = "lastErr"
    const val PAD_DP = "padDp"
    const val CORNER = "corner"
    const val SHOW_ALMANAC = "showAlmanac"
    const val LOCK_WP = "lockWp"
    const val WP_Y = "wpY"
    const val WP_COLOR = "wpColor"
    const val WP_SIG = "wpSig"

    /** Mặc định: công viên Đầm Sen, Quận 11, TP.HCM (xấp xỉ; Open-Meteo dùng lưới ~10 km nên sai số vài trăm mét không ảnh hưởng). */
    const val DEF_NAME = "Đầm Sen"
    const val DEF_LAT = 10.7632
    const val DEF_LON = 106.6355

    fun sp(c: Context) = c.getSharedPreferences("clockwidget", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun long(c: Context, k: String, d: Long): Long = sp(c).getLong(k, d)

    fun putInt(c: Context, k: String, v: Int) {
        sp(c).edit().putInt(k, v).apply()
    }

    fun putBool(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun putStr(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }

    fun putLong(c: Context, k: String, v: Long) {
        sp(c).edit().putLong(k, v).apply()
    }

    fun font(c: Context): Int = int(c, FONT, 0)
    fun textColor(c: Context): Int = int(c, TEXT_COLOR, -1)
    fun bgColor(c: Context): Int = int(c, BG_COLOR, -16777216)
    fun bgAlpha(c: Context): Int = int(c, BG_ALPHA, 35)
    fun showLunar(c: Context): Boolean = bool(c, SHOW_LUNAR, true)
    fun lunarDetail(c: Context): Boolean = bool(c, LUNAR_DETAIL, true)
    fun showCal(c: Context): Boolean = bool(c, SHOW_CAL, true)
    fun calGoogleOnly(c: Context): Boolean = bool(c, CAL_GOOGLE_ONLY, false)
    fun calHolidays(c: Context): Boolean = bool(c, CAL_HOLIDAYS, false)

    /** 0 = chữ "Thứ Năm"; 1 = thanh 7 ô T2..CN. */
    fun wdStyle(c: Context): Int = int(c, WD_STYLE, 0).coerceIn(0, 1)
    fun showWeather(c: Context): Boolean = bool(c, SHOW_WEATHER, true)
    fun showAlmanac(c: Context): Boolean = bool(c, SHOW_ALMANAC, true)
    fun lockWallpaper(c: Context): Boolean = bool(c, LOCK_WP, false)
    fun wpY(c: Context): Int = int(c, WP_Y, 38).coerceIn(15, 75)
    fun lockCard(c: Context): Boolean = bool(c, LOCK_CARD, false)
    fun lockStyle(c: Context): Int = int(c, LOCK_STYLE, 0)
    fun lockColor(c: Context): Int = int(c, LOCK_COLOR, 0)
    fun locName(c: Context): String = str(c, LOC_NAME, DEF_NAME)
    fun padDp(c: Context): Int = int(c, PAD_DP, 6).coerceIn(0, 24)
    fun corner(c: Context): Int = int(c, CORNER, 2).coerceIn(0, 3)

    private fun parseCoord(s: String, min: Double, max: Double, def: Double): Double {
        val v = s.trim().replace(',', '.').toDoubleOrNull() ?: return def
        return if (v < min || v > max) def else v
    }

    fun lat(c: Context): Double = parseCoord(str(c, LAT, DEF_LAT.toString()), -90.0, 90.0, DEF_LAT)
    fun lon(c: Context): Double = parseCoord(str(c, LON, DEF_LON.toString()), -180.0, 180.0, DEF_LON)
}
