package vn.xin.clockwidget

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

/**
 * Sự kiện lấy từ kho lịch của điện thoại (CalendarContract). Google Calendar hiện ở đây khi tài khoản Google
 * được bật đồng bộ Lịch trong Cài đặt > Tài khoản. App không gọi API của Google và không cần đăng nhập Google.
 * Dữ liệu đọc ở nền (job, báo thức, bấm widget) rồi lưu bản sao nhỏ; lúc vẽ chỉ lọc lại theo giờ hiện tại.
 */
object CalendarRepo {
    const val MAX_ROWS = 5
    private const val LOOKAHEAD_DAYS = 60L
    private const val KEEP = 24
    private const val DAY_MS = 86_400_000L

    class Result(val rows: List<String>, val state: Int) {
        companion object {
            const val OK = 0
            const val NO_PERMISSION = 1
            const val EMPTY = 2
        }
    }

    private class Ev(val begin: Long, val end: Long, val allDay: Boolean, val title: String)

    fun hasPermission(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Đọc kho lịch rồi lưu bản sao. Gọi ngoài luồng chính. Trả về true nếu đọc được. */
    fun refresh(ctx: Context): Boolean {
        if (!Prefs.showCal(ctx)) return true
        if (!hasPermission(ctx)) return false
        return try {
            val list = query(ctx)
            val arr = JSONArray()
            for (e in list.take(KEEP)) {
                arr.put(JSONObject().put("b", e.begin).put("e", e.end).put("a", e.allDay).put("t", e.title))
            }
            Prefs.putStr(ctx, Prefs.CAL_JSON, arr.toString())
            Prefs.putLong(ctx, Prefs.CAL_TIME, System.currentTimeMillis())
            true
        } catch (t: Throwable) {
            CrashLog.record(ctx, t, "CalendarRepo.refresh")
            false
        }
    }

    private fun query(ctx: Context): List<Ev> {
        val cr = ctx.contentResolver
        val zone = ZoneId.systemDefault()
        val startMs = LocalDate.now().atStartOfDay(zone).toInstant().toEpochMilli() - DAY_MS
        val endMs = startMs + (LOOKAHEAD_DAYS + 1) * DAY_MS

        // Chỉ lấy lịch đang hiển thị (và chỉ tài khoản Google nếu người dùng chọn như vậy).
        val googleOnly = Prefs.calGoogleOnly(ctx)
        val allowed = HashSet<Long>()
        cr.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.Calendars.VISIBLE),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                val visible = cur.getInt(2) == 1
                val type = cur.getString(1) ?: ""
                if (visible && (!googleOnly || type == "com.google")) allowed.add(cur.getLong(0))
            }
        }
        if (allowed.isEmpty()) return emptyList()

        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, startMs)
        ContentUris.appendId(b, endMs)
        val out = ArrayList<Ev>()
        cr.query(
            b.build(),
            arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY,
                CalendarContract.Instances.CALENDAR_ID,
                CalendarContract.Instances.SELF_ATTENDEE_STATUS
            ),
            null, null, CalendarContract.Instances.BEGIN + " ASC"
        )?.use { cur ->
            while (cur.moveToNext()) {
                if (!allowed.contains(cur.getLong(4))) continue
                // Bỏ sự kiện mình đã từ chối.
                if (cur.getInt(5) == CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED) continue
                val title = (cur.getString(0) ?: "").trim().ifEmpty { "(Không tiêu đề)" }
                out.add(Ev(cur.getLong(1), cur.getLong(2), cur.getInt(3) == 1, title))
            }
        }
        return out
    }

    private fun load(ctx: Context): List<Ev> {
        val json = Prefs.str(ctx, Prefs.CAL_JSON, "")
        if (json.isEmpty()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val out = ArrayList<Ev>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Ev(o.getLong("b"), o.getLong("e"), o.optBoolean("a", false), o.optString("t", "")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private class Row(val date: LocalDate, val sortKey: Long, val title: String)

    /** Tối đa [MAX_ROWS] dòng "dd/MM - Tên sự kiện", sắp theo ngày; sự kiện đã kết thúc thì bỏ. */
    fun upcoming(ctx: Context): Result {
        if (!hasPermission(ctx)) return Result(emptyList(), Result.NO_PERMISSION)
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val now = System.currentTimeMillis()
        val rows = ArrayList<Row>()

        for (e in load(ctx)) {
            if (e.allDay) {
                // Sự kiện cả ngày lưu theo UTC; END là đầu ngày kế tiếp.
                val s = LocalDate.ofEpochDay(Math.floorDiv(e.begin, DAY_MS))
                val endEx = LocalDate.ofEpochDay(Math.floorDiv(e.end, DAY_MS))
                if (!endEx.isAfter(today)) continue
                val d = if (s.isBefore(today)) today else s
                rows.add(Row(d, d.toEpochDay() * DAY_MS, e.title))
            } else {
                if (maxOf(e.begin, e.end) <= now) continue
                val s = Instant.ofEpochMilli(e.begin).atZone(zone).toLocalDate()
                val d = if (s.isBefore(today)) today else s
                rows.add(Row(d, e.begin.coerceAtLeast(d.atStartOfDay(zone).toInstant().toEpochMilli()) + DAY_MS, e.title))
            }
        }

        if (Prefs.calHolidays(ctx)) {
            for (i in 0..45) {
                val d = today.plusDays(i.toLong())
                for (h in VnText.holidays(d)) rows.add(Row(d, d.toEpochDay() * DAY_MS + 1, h))
            }
        }

        rows.sortWith(compareBy<Row>({ it.date.toEpochDay() }, { it.sortKey }))
        val seen = HashSet<String>()
        val out = ArrayList<String>()
        for (r in rows) {
            if (!seen.add(r.date.toString() + "|" + r.title.lowercase(Locale.ROOT))) continue
            out.add(String.format(Locale.US, "%02d/%02d - %s", r.date.dayOfMonth, r.date.monthValue, r.title))
            if (out.size >= MAX_ROWS) break
        }
        return Result(out, if (out.isEmpty()) Result.EMPTY else Result.OK)
    }
}
