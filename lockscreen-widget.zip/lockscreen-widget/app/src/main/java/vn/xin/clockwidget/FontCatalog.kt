package vn.xin.clockwidget

/**
 * Bộ phông và hệ chữ, sinh tự động (đừng sửa tay).
 * Mỗi bộ có 3 phông: số lớn (ngày, nhiệt độ, ngày âm), tiêu đề (tháng, thứ), nội dung.
 * Mỗi layout có 2 biến thể bóng chữ: 0 = bóng đen (cho chữ sáng), 1 = quầng sáng (cho chữ tối).
 * refHeightDp: chiều cao khung cần có ở độ rộng chuẩn 360 dp, đo từ số liệu dòng của chính các phông đó.
 */
class FontEntry(
    val label: String,
    val refHeightDp: Int,
    private val w: IntArray,
    private val n: IntArray,
    private val nb: IntArray,
    private val wp: IntArray
) {
    fun widget(g: Int): Int = w[g]
    fun notifSmall(g: Int): Int = n[g]
    fun notifBig(g: Int): Int = nb[g]
    fun wall(g: Int): Int = wp[g]
}

object FontCatalog {
    val all: List<FontEntry> = listOf(
        FontEntry("Be Vietnam Pro: hiện đại, thiết kế riêng cho tiếng Việt", 273, intArrayOf(R.layout.w_be_vietnam_pro, R.layout.w_be_vietnam_pro_l), intArrayOf(R.layout.n_be_vietnam_pro, R.layout.n_be_vietnam_pro_l), intArrayOf(R.layout.nb_be_vietnam_pro, R.layout.nb_be_vietnam_pro_l), intArrayOf(R.layout.wp_be_vietnam_pro, R.layout.wp_be_vietnam_pro_l)),
        FontEntry("Montserrat: hình học, rộng, rõ nét", 264, intArrayOf(R.layout.w_montserrat, R.layout.w_montserrat_l), intArrayOf(R.layout.n_montserrat, R.layout.n_montserrat_l), intArrayOf(R.layout.nb_montserrat, R.layout.nb_montserrat_l), intArrayOf(R.layout.wp_montserrat, R.layout.wp_montserrat_l)),
        FontEntry("Nunito: bo tròn, mềm", 292, intArrayOf(R.layout.w_nunito, R.layout.w_nunito_l), intArrayOf(R.layout.n_nunito, R.layout.n_nunito_l), intArrayOf(R.layout.nb_nunito, R.layout.nb_nunito_l), intArrayOf(R.layout.wp_nunito, R.layout.wp_nunito_l)),
        FontEntry("Lora: serif dễ đọc, trang nhã", 276, intArrayOf(R.layout.w_lora, R.layout.w_lora_l), intArrayOf(R.layout.n_lora, R.layout.n_lora_l), intArrayOf(R.layout.nb_lora, R.layout.nb_lora_l), intArrayOf(R.layout.wp_lora, R.layout.wp_lora_l)),
        FontEntry("Oswald (số lớn) + Be Vietnam Pro: số hẹp, đậm", 287, intArrayOf(R.layout.w_oswald, R.layout.w_oswald_l), intArrayOf(R.layout.n_oswald, R.layout.n_oswald_l), intArrayOf(R.layout.nb_oswald, R.layout.nb_oswald_l), intArrayOf(R.layout.wp_oswald, R.layout.wp_oswald_l)),
        FontEntry("Roboto Mono (số lớn) + Be Vietnam Pro: kiểu số kỹ thuật", 277, intArrayOf(R.layout.w_roboto_mono, R.layout.w_roboto_mono_l), intArrayOf(R.layout.n_roboto_mono, R.layout.n_roboto_mono_l), intArrayOf(R.layout.nb_roboto_mono, R.layout.nb_roboto_mono_l), intArrayOf(R.layout.wp_roboto_mono, R.layout.wp_roboto_mono_l))
    )

    fun get(i: Int): FontEntry = all[i.coerceIn(0, all.size - 1)]
}
