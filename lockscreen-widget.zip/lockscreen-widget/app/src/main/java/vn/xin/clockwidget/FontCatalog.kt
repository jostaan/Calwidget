package vn.xin.clockwidget

/**
 * Bộ phông và hệ chữ, sinh tự động (đừng sửa tay).
 * Mỗi bộ gồm 3 vai trò: đồng hồ (hiển thị), tiêu đề (đậm), nội dung (thường).
 * refHeightDp: chiều cao nội dung cần có ở độ rộng chuẩn 360 dp, đo từ số liệu dòng của chính các phông đó.
 */
class FontEntry(
    val label: String,
    val widgetLayout: Int,
    val notifLayout: Int,
    val notifBigLayout: Int,
    val wallLayout: Int,
    val refHeightDp: Int
)

object FontCatalog {
    val all: List<FontEntry> = listOf(
        FontEntry("Be Vietnam Pro: hiện đại, thiết kế riêng cho tiếng Việt", R.layout.w_be_vietnam_pro, R.layout.n_be_vietnam_pro, R.layout.nb_be_vietnam_pro, R.layout.wp_be_vietnam_pro, 166),
        FontEntry("Montserrat: hình học, rộng, rõ nét", R.layout.w_montserrat, R.layout.n_montserrat, R.layout.nb_montserrat, R.layout.wp_montserrat, 162),
        FontEntry("Nunito: bo tròn, mềm", R.layout.w_nunito, R.layout.n_nunito, R.layout.nb_nunito, R.layout.wp_nunito, 178),
        FontEntry("Lora: serif dễ đọc, trang nhã", R.layout.w_lora, R.layout.n_lora, R.layout.nb_lora, R.layout.wp_lora, 168),
        FontEntry("Oswald (giờ) + Be Vietnam Pro: giờ hẹp, đậm", R.layout.w_oswald, R.layout.n_oswald, R.layout.nb_oswald, R.layout.wp_oswald, 176),
        FontEntry("Roboto Mono (giờ) + Be Vietnam Pro: kiểu đồng hồ số", R.layout.w_roboto_mono, R.layout.n_roboto_mono, R.layout.nb_roboto_mono, R.layout.wp_roboto_mono, 168)
    )

    fun get(i: Int): FontEntry = all[i.coerceIn(0, all.size - 1)]
}
