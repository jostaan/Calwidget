package vn.xin.clockwidget;

/**
 * Âm lịch Việt Nam (múi giờ UTC+7), thuật toán thiên văn của Hồ Ngọc Đức.
 * Không phụ thuộc Android để kiểm thử được bằng javac.
 */
public final class LunarCalendar {
    private LunarCalendar() {}

    public static final double TZ = 7.0;

    public static final String[] CAN = {"Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"};
    public static final String[] CHI = {"Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"};

    /** Chỉ số 0..23 theo thứ tự góc Mặt Trời 0°, 15°, ... (0 = Xuân phân). */
    public static final String[] TIET_KHI = {
        "Xuân phân", "Thanh minh", "Cốc vũ", "Lập hạ", "Tiểu mãn", "Mang chủng",
        "Hạ chí", "Tiểu thử", "Đại thử", "Lập thu", "Xử thử", "Bạch lộ",
        "Thu phân", "Hàn lộ", "Sương giáng", "Lập đông", "Tiểu tuyết", "Đại tuyết",
        "Đông chí", "Tiểu hàn", "Đại hàn", "Lập xuân", "Vũ thủy", "Kinh trập"
    };

    /** Kết quả chuyển đổi một ngày dương sang âm. */
    public static final class Lunar {
        public final int day;
        public final int month;
        public final int year;
        public final boolean leap;
        public final int jd;

        Lunar(int day, int month, int year, boolean leap, int jd) {
            this.day = day;
            this.month = month;
            this.year = year;
            this.leap = leap;
            this.jd = jd;
        }

        public String yearCanChi() {
            return CAN[(year + 6) % 10] + " " + CHI[(year + 8) % 12];
        }

        public String monthCanChi() {
            return CAN[(year * 12 + month + 3) % 10] + " " + CHI[(month + 1) % 12];
        }

        public String dayCanChi() {
            return CAN[(jd + 9) % 10] + " " + CHI[(jd + 1) % 12];
        }
    }

    private static int intFloor(double d) {
        return (int) Math.floor(d);
    }

    public static int jdFromDate(int dd, int mm, int yy) {
        int a = (14 - mm) / 12;
        int y = yy + 4800 - a;
        int m = mm + 12 * a - 3;
        int jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
        if (jd < 2299161) {
            jd = dd + (153 * m + 2) / 5 + 365 * y + y / 4 - 32083;
        }
        return jd;
    }

    static int newMoonDay(int k) {
        double t = k / 1236.85;
        double t2 = t * t;
        double t3 = t2 * t;
        double dr = Math.PI / 180;
        double jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3;
        jd1 = jd1 + 0.00033 * Math.sin((166.56 + 132.87 * t - 0.009173 * t2) * dr);
        double m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3;
        double mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3;
        double f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3;
        double c1 = (0.1734 - 0.000393 * t) * Math.sin(m * dr) + 0.0021 * Math.sin(2 * dr * m);
        c1 = c1 - 0.4068 * Math.sin(mpr * dr) + 0.0161 * Math.sin(dr * 2 * mpr);
        c1 = c1 - 0.0004 * Math.sin(dr * 3 * mpr);
        c1 = c1 + 0.0104 * Math.sin(dr * 2 * f) - 0.0051 * Math.sin(dr * (m + mpr));
        c1 = c1 - 0.0074 * Math.sin(dr * (m - mpr)) + 0.0004 * Math.sin(dr * (2 * f + m));
        c1 = c1 - 0.0004 * Math.sin(dr * (2 * f - m)) - 0.0006 * Math.sin(dr * (2 * f + mpr));
        c1 = c1 + 0.0010 * Math.sin(dr * (2 * f - mpr)) + 0.0005 * Math.sin(dr * (2 * mpr + m));
        double deltat;
        if (t < -11) {
            deltat = 0.001 + 0.000839 * t + 0.0002261 * t2 - 0.00000845 * t3 - 0.000000081 * t * t3;
        } else {
            deltat = -0.000278 + 0.000265 * t + 0.000262 * t2;
        }
        double jdNew = jd1 + c1 - deltat;
        return intFloor(jdNew + 0.5 + TZ / 24);
    }

    /** Góc Mặt Trời tại 0h địa phương của ngày jdn, tính bằng radian trong [0, 2π). */
    static double sunLongitudeRad(double jdn) {
        double t = (jdn - 2451545.5 - TZ / 24) / 36525;
        double t2 = t * t;
        double dr = Math.PI / 180;
        double m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2;
        double l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2;
        double dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * Math.sin(dr * m);
        dl = dl + (0.019993 - 0.000101 * t) * Math.sin(dr * 2 * m) + 0.000290 * Math.sin(dr * 3 * m);
        double l = (l0 + dl) * dr;
        l = l - Math.PI * 2 * intFloor(l / (Math.PI * 2));
        return l;
    }

    /** 0..11, mỗi bước 30°: dùng cho quy tắc tháng nhuận. */
    static int sunLongitude(double jdn) {
        return intFloor(sunLongitudeRad(jdn) / Math.PI * 6);
    }

    /** 0..23, mỗi bước 15°: dùng cho tiết khí. */
    public static int solarTermIndex(int jdn) {
        return intFloor(sunLongitudeRad(jdn) / Math.PI * 12);
    }

    /**
     * Tên tiết khí nếu tiết khí bắt đầu trong ngày jd, ngược lại null.
     * Góc Mặt Trời được tính tại 0h đầu ngày, nên tiết khí rơi vào ngày jd
     * khi chỉ số đổi giữa 0h ngày jd và 0h ngày jd+1.
     */
    public static String solarTermStartingOn(int jd) {
        int before = solarTermIndex(jd);
        int after = solarTermIndex(jd + 1);
        return before != after ? TIET_KHI[after] : null;
    }

    static int lunarMonth11(int yy) {
        double off = jdFromDate(31, 12, yy) - 2415021.0;
        int k = intFloor(off / 29.530588853);
        int nm = newMoonDay(k);
        int sunLong = sunLongitude(nm);
        if (sunLong >= 9) {
            nm = newMoonDay(k - 1);
        }
        return nm;
    }

    static int leapMonthOffset(int a11) {
        int k = intFloor((a11 - 2415021.076998695) / 29.530588853 + 0.5);
        int last;
        int i = 1;
        int arc = sunLongitude(newMoonDay(k + i));
        do {
            last = arc;
            i++;
            arc = sunLongitude(newMoonDay(k + i));
        } while (arc != last && i < 14);
        return i - 1;
    }

    public static Lunar fromSolar(int dd, int mm, int yy) {
        int dayNumber = jdFromDate(dd, mm, yy);
        int k = intFloor((dayNumber - 2415021.076998695) / 29.530588853);
        int monthStart = newMoonDay(k + 1);
        if (monthStart > dayNumber) {
            monthStart = newMoonDay(k);
        }
        int a11 = lunarMonth11(yy);
        int b11 = a11;
        int lunarYear;
        if (a11 >= monthStart) {
            lunarYear = yy;
            a11 = lunarMonth11(yy - 1);
        } else {
            lunarYear = yy + 1;
            b11 = lunarMonth11(yy + 1);
        }
        int lunarDay = dayNumber - monthStart + 1;
        int diff = intFloor((monthStart - a11) / 29.0);
        boolean leap = false;
        int lunarMonth = diff + 11;
        if (b11 - a11 > 365) {
            int leapMonthDiff = leapMonthOffset(a11);
            if (diff >= leapMonthDiff) {
                lunarMonth = diff + 10;
                if (diff == leapMonthDiff) {
                    leap = true;
                }
            }
        }
        if (lunarMonth > 12) {
            lunarMonth = lunarMonth - 12;
        }
        if (lunarMonth >= 11 && diff < 4) {
            lunarYear -= 1;
        }
        return new Lunar(lunarDay, lunarMonth, lunarYear, leap, dayNumber);
    }
}
