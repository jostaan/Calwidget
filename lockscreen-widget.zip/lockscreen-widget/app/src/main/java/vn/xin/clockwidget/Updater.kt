package vn.xin.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.ZoneId

/** Cập nhật widget và thẻ khóa; lập lịch lấy thời tiết định kỳ và làm mới lúc qua nửa đêm. */
object Updater {
    private const val JOB_ID = 7302
    private const val OLD_JOB_ID = 7301
    const val ACTION_REFRESH = "vn.xin.clockwidget.REFRESH"
    private const val ACTION_MIDNIGHT = "vn.xin.clockwidget.MIDNIGHT"
    private const val ACTION_TICK = "vn.xin.clockwidget.TICK"
    private const val PERIOD_MS = 60 * 60 * 1000L

    /**
     * Dữ liệu cũ hơn ngưỡng này thì lấy lại khi có tín hiệu nền. Thấp hơn chu kỳ 60 phút một chút để
     * job và báo thức (lệch pha nhau) không "chê" dữ liệu còn mới rồi bỏ qua cả hai, kéo giãn thành 2 giờ.
     */
    private const val STALE_MINUTES = 45L
    private const val REFRESHING_WINDOW_MS = 45_000L

    fun widgetIds(c: Context): IntArray {
        val mgr = AppWidgetManager.getInstance(c)
        return mgr.getAppWidgetIds(ComponentName(c, ClockWidgetProvider::class.java))
    }

    /** Vẽ lại tất cả widget và thẻ khóa từ dữ liệu đã lưu. Nhanh, không dùng mạng. */
    fun updateWidgets(ctx: Context) {
        val c = ctx.applicationContext
        try {
            val mgr = AppWidgetManager.getInstance(c)
            for (id in widgetIds(c)) {
                // Mỗi widget vẽ riêng: một widget lỗi không làm hỏng widget khác hay thẻ khóa.
                try {
                    val opt = mgr.getAppWidgetOptions(id)
                    // Chế độ dọc: rộng = MIN_WIDTH, cao = MAX_HEIGHT.
                    val wDp = opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
                    val hDp = opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
                    mgr.updateAppWidget(id, Renderer.widgetViews(c, wDp, hDp))
                } catch (t: Throwable) {
                    CrashLog.record(c, t, "updateAll/widget $id")
                }
            }
        } catch (t: Throwable) {
            CrashLog.record(c, t, "updateAll")
        }
        try {
            LockCard.update(c)
        } catch (t: Throwable) {
            CrashLog.record(c, t, "updateAll/lockcard")
        }
    }

    /** Vẽ lại và đặt ảnh nền khóa nếu đang bật (chậm hơn: dựng bitmap cả màn hình). */
    fun updateWallpaper(ctx: Context) {
        val c = ctx.applicationContext
        try {
            LockWallpaper.update(c)
        } catch (t: Throwable) {
            CrashLog.record(c, t, "updateAll/lockwallpaper")
        }
    }

    /** Widget, thẻ khóa rồi ảnh nền khóa. */
    fun updateAll(ctx: Context) {
        updateWidgets(ctx)
        updateWallpaper(ctx)
    }

    /** Lấy thời tiết mới nếu dữ liệu cũ hơn [STALE_MINUTES] (hoặc force). Gọi ngoài luồng chính. */
    fun refreshWeather(ctx: Context, force: Boolean, budgetMs: Long = 25_000L): Boolean {
        val c = ctx.applicationContext
        if (!force && WeatherRepo.ageMinutes(c) < STALE_MINUTES) return true
        return WeatherRepo.refresh(c, budgetMs)
    }

    /** Làm mới toàn bộ dữ liệu: thời tiết (qua mạng) và sự kiện lịch (đọc kho lịch trên máy). */
    fun refreshData(ctx: Context, force: Boolean, budgetMs: Long = 25_000L) {
        val c = ctx.applicationContext
        try {
            refreshWeather(c, force, budgetMs)
        } catch (t: Throwable) {
            CrashLog.record(c, t, "refreshData/weather")
        }
        try {
            CalendarRepo.refresh(c)
        } catch (t: Throwable) {
            CrashLog.record(c, t, "refreshData/calendar")
        }
    }

    /** Đang trong lúc làm mới do người dùng bấm widget (hiện "Đang cập nhật…"). */
    fun isRefreshing(c: Context): Boolean {
        val t = Prefs.long(c, Prefs.REFRESHING_AT, 0L)
        val d = System.currentTimeMillis() - t
        return t != 0L && d in 0..REFRESHING_WINDOW_MS
    }

    /** PendingIntent cho thao tác bấm vào widget: gửi lệnh làm mới thời tiết và sự kiện. */
    fun refreshPi(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c,
            15,
            Intent(c, SystemReceiver::class.java).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Có cần chạy nền không: có widget trên màn hình hoặc bật thẻ khóa. */
    private fun needed(c: Context): Boolean = widgetIds(c).isNotEmpty() || Prefs.lockCard(c)

    /** Mỗi bước được bọc riêng: một lỗi lập lịch không được làm văng app hay các bước còn lại. */
    fun scheduleAll(ctx: Context) {
        val c = ctx.applicationContext
        val need = try {
            needed(c)
        } catch (e: Throwable) {
            CrashLog.record(c, e, "scheduleAll/needed")
            return
        }
        if (!need) {
            try {
                cancelAll(c)
            } catch (e: Throwable) {
                CrashLog.record(c, e, "cancelAll")
            }
            return
        }
        try {
            scheduleJob(c)
        } catch (e: Throwable) {
            CrashLog.record(c, e, "scheduleJob")
        }
        try {
            scheduleMidnight(c)
        } catch (e: Throwable) {
            CrashLog.record(c, e, "scheduleMidnight")
        }
        try {
            scheduleTick(c)
        } catch (e: Throwable) {
            CrashLog.record(c, e, "scheduleTick")
        }
    }

    /** Có job định kỳ đang chờ không (dùng cho báo cáo chẩn đoán). */
    fun jobPending(c: Context): Boolean =
        c.getSystemService(JobScheduler::class.java).getPendingJob(JOB_ID) != null

    private fun scheduleJob(c: Context) {
        val js = c.getSystemService(JobScheduler::class.java)
        js.cancel(OLD_JOB_ID) // job 30 phút của bản trước
        if (js.getPendingJob(JOB_ID) != null) return
        val info = JobInfo.Builder(JOB_ID, ComponentName(c, WeatherJobService::class.java))
            .setPeriodic(PERIOD_MS)
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .build()
        js.schedule(info)
    }

    private fun midnightPi(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c,
            91,
            Intent(c, SystemReceiver::class.java).setAction(ACTION_MIDNIGHT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun scheduleMidnight(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = midnightPi(c)
        val next = LocalDate.now().plusDays(1)
            .atStartOfDay(ZoneId.systemDefault())
            .plusSeconds(20)
            .toInstant()
            .toEpochMilli()
        var done = false
        if (am.canScheduleExactAlarms()) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
                done = true
            } catch (e: SecurityException) {
                // ROM không cấp quyền báo thức chính xác: dùng báo thức gần đúng.
            }
        }
        if (!done) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }

    private fun tickPi(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c,
            92,
            Intent(c, SystemReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /**
     * Báo thức gần đúng mỗi ~60 phút, độc lập với JobScheduler: nếu job bị ROM chặn hoặc lập lịch lỗi,
     * chuỗi này vẫn kéo thời tiết về. Mỗi lần nổ, SystemReceiver gọi scheduleAll để đặt lại báo thức kế tiếp.
     */
    private fun scheduleTick(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + PERIOD_MS, tickPi(c))
    }

    fun cancelAll(ctx: Context) {
        val c = ctx.applicationContext
        c.getSystemService(JobScheduler::class.java).cancel(JOB_ID)
        c.getSystemService(JobScheduler::class.java).cancel(OLD_JOB_ID)
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(midnightPi(c))
        am.cancel(tickPi(c))
    }
}
