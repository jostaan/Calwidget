package vn.xin.clockwidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/**
 * Dựng RemoteViews cho widget, thẻ khóa và khối thông tin trên ảnh nền khóa.
 *
 * Bố cục 2 cột x 2 hàng (màn hình khóa của hệ thống đã có đồng hồ nên không vẽ giờ):
 *   trên-trái: tháng / NGÀY lớn / thứ (chữ hoặc thanh 7 ô)    trên-phải: thời tiết (NHIỆT ĐỘ lớn, gió, UV, AQI)
 *   dưới-trái: âm lịch, hoàng đạo/hắc đạo (chấm), tiết khí     dưới-phải: tối đa 5 sự kiện từ lịch
 *
 * Hệ chữ (cố định, không tự co), 6 vai trò, cỡ chuẩn ở widget rộng 360 dp:
 *   Ngày 60 · Nhiệt độ 40 · Ngày âm 24 · Tiêu đề 16 (tháng, thứ) · Nội dung 13 · Chú thích 12
 * Cỡ thực = cỡ chuẩn x hệ số tỉ lệ; hệ số tính một lần từ kích thước widget (xem [scaleFor]).
 * Phông và chiều cao tham chiếu theo từng bộ phông ở [FontCatalog]. Chữ sáng dùng bóng đen, chữ tối dùng quầng sáng.
 */
object Renderer {
    private const val HERO = 60f
    private const val DISPLAY = 40f
    private const val TITLE = 24f
    private const val HEADING = 16f
    private const val BODY = 13f
    private const val CAPTION = 12f
    private const val ICON_DP = 36f
    private const val DOT_DP = 10f

    /** Bề rộng nội dung chuẩn: widget 360 dp trừ lề 6 dp hai bên. */
    private const val REF_INNER_W = 348f
    private const val REF_PAD = 12f
    private const val SCALE_STEP = 0.05f

    private val CORNER_DRAWABLES = intArrayOf(R.drawable.bg_r0, R.drawable.bg_r12, R.drawable.bg_r22, R.drawable.bg_r32)
    private val WD_TEXT = intArrayOf(R.id.wd1, R.id.wd2, R.id.wd3, R.id.wd4, R.id.wd5, R.id.wd6, R.id.wd7)
    private val WD_PILL = intArrayOf(R.id.wp1, R.id.wp2, R.id.wp3, R.id.wp4, R.id.wp5, R.id.wp6, R.id.wp7)
    private val EV_IDS = intArrayOf(R.id.ev1, R.id.ev2, R.id.ev3, R.id.ev4, R.id.ev5)
    private val WIND_NAMES = arrayOf("Bắc", "Đông Bắc", "Đông", "Đông Nam", "Nam", "Tây Nam", "Tây", "Tây Bắc")

    /** Nội dung từng ô. null = ẩn dòng đó. */
    class Cells {
        // trên-trái
        var weekdayIdx = 1 // 1 = thứ Hai ... 7 = Chủ Nhật
        var dtM: String? = null
        var dtD: String? = null
        var dtW: String? = null

        // trên-phải
        var wxOn = true
        var wxIcon = R.drawable.ic_wx_cloud
        var wx1: String? = null
        var wx1b: String? = null
        var wx2: String? = null
        var wx3: String? = null
        var wx4: String? = null
        var wx5: String? = null

        // dưới-trái
        var luOn = true
        var lu0: String? = null
        var lu1: String? = null
        var lu2: String? = null
        var hdOn = false
        var hdGood = true
        var lu3: String? = null
        var lu3b: String? = null
        var lu4: String? = null
        var lu5: String? = null
        var hours: String? = null

        // dưới-phải
        var calOn = true
        var ev0: String? = null
        val ev = ArrayList<String>()
    }

    private fun join(parts: List<String?>): String? {
        val p = parts.filter { !it.isNullOrEmpty() }
        return if (p.isEmpty()) null else p.joinToString(" · ")
    }

    private fun uvShort(uv: Double): String = when {
        uv < 3 -> "thấp"
        uv < 6 -> "vừa"
        uv < 8 -> "cao"
        uv < 11 -> "rất cao"
        else -> "cực cao"
    }

    private fun aqiShort(aqi: Int): String = when {
        aqi <= 50 -> "tốt"
        aqi <= 100 -> "vừa"
        aqi <= 150 -> "kém"
        aqi <= 200 -> "xấu"
        aqi <= 300 -> "rất xấu"
        else -> "nguy hại"
    }

    /** Hướng gió là hướng gió thổi TỪ đó đến (quy ước khí tượng, trùng cách gọi "gió Đông Nam"). */
    private fun windName(deg: Double): String {
        val i = Math.floor((deg + 22.5) / 45.0).toInt()
        return WIND_NAMES[Math.floorMod(i, 8)]
    }

    private fun iconFor(code: Int, isDay: Boolean): Int = when (code) {
        0, 1 -> if (isDay) R.drawable.ic_wx_sun else R.drawable.ic_wx_moon
        2 -> if (isDay) R.drawable.ic_wx_partly_day else R.drawable.ic_wx_partly_night
        3 -> R.drawable.ic_wx_cloud
        45, 48 -> R.drawable.ic_wx_fog
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.ic_wx_rain
        71, 73, 75, 77, 85, 86 -> R.drawable.ic_wx_snow
        95, 96, 99 -> R.drawable.ic_wx_thunder
        else -> R.drawable.ic_wx_cloud
    }

    // ---------- Nội dung các ô ----------

    private fun dateCells(today: LocalDate, c: Cells) {
        c.weekdayIdx = today.dayOfWeek.value
        c.dtM = VnText.monthName(today.monthValue)
        c.dtD = today.dayOfMonth.toString()
        c.dtW = VnText.weekday(today.dayOfWeek)
    }

    private fun lunarCells(ctx: Context, today: LocalDate, c: Cells) {
        val showLunar = Prefs.showLunar(ctx)
        val showAlmanac = Prefs.showAlmanac(ctx)
        c.luOn = showLunar || showAlmanac
        if (!c.luOn) return
        val lunar = LunarCalendar.fromSolar(today.dayOfMonth, today.monthValue, today.year)
        val detail = Prefs.lunarDetail(ctx)

        if (showLunar) {
            val label = if (lunar.leap) "Tháng nhuận" else "Âm lịch"
            c.lu0 = if (detail) {
                if (lunar.leap) "Nhuận · năm ${lunar.yearCanChi()}" else "$label · năm ${lunar.yearCanChi()}"
            } else label
            c.lu1 = "${lunar.day}/${lunar.month}"
            if (detail) c.lu2 = "Ngày ${lunar.dayCanChi()}"
        }
        if (showAlmanac) {
            c.hdOn = true
            c.hdGood = Almanac.isGoodDay(lunar.month, lunar.jd)
            c.lu3 = if (c.hdGood) "Hoàng đạo" else "Hắc đạo"
            c.lu3b = Almanac.starName(lunar.month, lunar.jd)
            c.hours = Almanac.goodHours(lunar.jd, false)
        }

        // Tiết khí đang có hiệu lực (kể cả hôm nay là ngày vào tiết) và tiết kế tiếp.
        val jd = lunar.jd
        val cur = LunarCalendar.TIET_KHI[Math.floorMod(LunarCalendar.solarTermIndex(jd + 1), 24)]
        c.lu4 = "Tiết $cur"
        val startsToday = LunarCalendar.solarTermStartingOn(jd) != null
        var n = 1
        var next: String? = null
        while (n <= 20) {
            next = LunarCalendar.solarTermStartingOn(jd + n)
            if (next != null) break
            n++
        }
        c.lu5 = when {
            startsToday -> "Bắt đầu hôm nay"
            next == null -> null
            n == 1 -> "$next vào ngày mai"
            else -> "$next sau $n ngày"
        }
    }

    private fun weatherCells(ctx: Context, c: Cells, widgetMode: Boolean) {
        c.wxOn = Prefs.showWeather(ctx)
        if (!c.wxOn) return
        // Trạng thái "đang cập nhật" chỉ hiện ở widget: ở ảnh nền khóa nó sẽ làm đổi ảnh mỗi lần bấm.
        val refreshing = widgetMode && Updater.isRefreshing(ctx)
        val loc = Prefs.locName(ctx)
        val w = WeatherRepo.load(ctx)
        if (w == null) {
            c.wx1 = "--°C"
            c.wx1b = "Chưa có dữ liệu"
            c.wx2 = "Chạm widget để cập nhật"
            c.wx5 = if (refreshing) "Đang cập nhật…" else loc
            return
        }
        c.wxIcon = iconFor(w.code, w.isDay)
        c.wx1 = "${Math.round(w.tempC)}°C"
        c.wx1b = VnText.weatherDesc(w.code)

        if (!w.windKmh.isNaN()) {
            val spd = "${Math.round(w.windKmh)} km/h"
            c.wx2 = if (!w.windDeg.isNaN()) "Gió ${windName(w.windDeg)} $spd" else "Gió $spd"
        }
        // UV là chỉ số cao nhất trong ngày (Open-Meteo daily), nên ghi rõ "đỉnh".
        if (!w.uvMax.isNaN()) c.wx3 = "UV đỉnh ${Math.round(w.uvMax)} (${uvShort(w.uvMax)})"
        if (w.aqi >= 0) c.wx4 = "AQI ${w.aqi} (${aqiShort(w.aqi)})"

        c.wx5 = when {
            refreshing -> "Đang cập nhật…"
            WeatherRepo.ageMinutes(ctx) > 90 -> "$loc · cập nhật " + SimpleDateFormat("HH:mm", Locale.US).format(Date(w.fetchedAt))
            w.humidity >= 0 -> "$loc · ẩm ${w.humidity}%"
            else -> loc
        }
    }

    private fun calendarCells(ctx: Context, c: Cells) {
        c.calOn = Prefs.showCal(ctx)
        if (!c.calOn) return
        c.ev0 = "Sự kiện sắp tới"
        val r = CalendarRepo.upcoming(ctx)
        when (r.state) {
            CalendarRepo.Result.OK -> c.ev.addAll(r.rows)
            CalendarRepo.Result.NO_PERMISSION -> {
                c.ev.add("Chưa cấp quyền đọc Lịch")
                c.ev.add("Mở app để cấp quyền")
            }
            else -> c.ev.add("Không có sự kiện sắp tới")
        }
    }

    /** widgetMode: có hiện trạng thái "đang cập nhật" hay không (chỉ widget). */
    fun cells(ctx: Context, widgetMode: Boolean = false): Cells {
        val c = Cells()
        val today = LocalDate.now()
        dateCells(today, c)
        lunarCells(ctx, today, c)
        weatherCells(ctx, c, widgetMode)
        calendarCells(ctx, c)
        return c
    }

    /** Văn bản thuần cho kiểu thẻ khóa "văn bản đơn giản" và để nhận biết nội dung ảnh nền khóa đã đổi chưa. */
    fun plainLines(ctx: Context): List<String> {
        val c = cells(ctx)
        val today = LocalDate.now()
        val out = ArrayList<String>()
        out.add(String.format(Locale.US, "%s, %02d/%02d/%d", c.dtW, today.dayOfMonth, today.monthValue, today.year))
        if (c.luOn) {
            c.lu1?.let { out.add(join(listOf("Âm lịch $it", c.lu2)) ?: "") }
            if (c.hdOn) out.add(join(listOf(c.lu3, c.lu3b)) ?: "")
            c.hours?.let { out.add("Giờ hoàng đạo: $it") }
            join(listOf(c.lu4, c.lu5))?.let { out.add(it) }
        }
        if (c.wxOn) {
            join(listOf(c.wx1, c.wx1b))?.let { out.add(it) }
            c.wx2?.let { out.add(it) }
            join(listOf(c.wx3, c.wx4))?.let { out.add(it) }
            c.wx5?.let { out.add(it) }
        }
        if (c.calOn) out.addAll(c.ev)
        return out
    }

    // ---------- Hệ số tỉ lệ ----------

    private fun fontScale(ctx: Context): Float {
        val f = ctx.resources.configuration.fontScale
        return if (f > 0.5f) f else 1f
    }

    private fun snap(s: Float): Float = Math.floor((s / SCALE_STEP).toDouble()).toFloat() * SCALE_STEP

    /**
     * Hệ số tỉ lệ của hệ chữ so với widget chuẩn: nhỏ hơn trong hai tỉ lệ rộng và cao, để cả hai chiều đều vừa.
     * Làm tròn xuống bội của 0,05 và giới hạn 0,7 đến 1,8: cùng một kích thước widget luôn ra cùng một cỡ chữ.
     */
    fun scaleFor(ctx: Context, widthDp: Float, heightDp: Float, padDp: Float): Float {
        val f = FontCatalog.get(Prefs.font(ctx))
        val sw = (widthDp - 2 * padDp) / REF_INNER_W
        val sh = (heightDp - 2 * padDp) / (f.refHeightDp - REF_PAD)
        return snap(Math.min(sw, sh).coerceIn(0.7f, 1.8f))
    }

    // ---------- Màu, bóng chữ ----------

    private fun luminance(color: Int): Float =
        (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) / 255f

    /** 0 = bóng đen (chữ sáng); 1 = quầng sáng (chữ tối, nếu không bóng đen không nhìn thấy). */
    fun shadowGroup(color: Int): Int = if (luminance(color) < 0.45f) 1 else 0

    /** Màu chữ nằm trên nền "viên thuốc" tô bằng màu chữ: đen nếu chữ sáng, trắng nếu chữ tối. */
    private fun onFill(color: Int): Int = if (luminance(color) > 0.55f) Color.BLACK else Color.WHITE

    private fun opaque(color: Int): Int = Color.rgb(Color.red(color), Color.green(color), Color.blue(color))

    /** Chữ phụ (chú thích): nhạt hơn một chút so với chữ chính. */
    private fun dim(color: Int): Int =
        Color.argb((Color.alpha(color) * 0.8f).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    // ---------- Thao tác với RemoteViews ----------

    private fun roundHalf(v: Float): Float = Math.round(v * 2f) / 2f

    private fun put(rv: RemoteViews, id: Int, text: String?, color: Int, roleSp: Float, k: Float) {
        if (text.isNullOrEmpty()) {
            rv.setViewVisibility(id, View.GONE)
        } else {
            rv.setViewVisibility(id, View.VISIBLE)
            rv.setTextViewText(id, text)
            rv.setTextColor(id, color)
            rv.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, roundHalf(roleSp * k))
        }
    }

    private fun setBox(rv: RemoteViews, id: Int, w: Float, h: Float) {
        rv.setViewLayoutWidth(id, w, TypedValue.COMPLEX_UNIT_DIP)
        rv.setViewLayoutHeight(id, h, TypedValue.COMPLEX_UNIT_DIP)
    }

    /** Điền nội dung vào bố cục 2x2. s: hệ số tỉ lệ của hệ chữ. */
    private fun fill(ctx: Context, rv: RemoteViews, c: Cells, color: Int, s: Float) {
        val soft = dim(color)
        val k = s / fontScale(ctx)

        // Trên-trái: tháng, ngày, thứ.
        put(rv, R.id.dt_m, c.dtM, color, HEADING, k)
        put(rv, R.id.dt_d, c.dtD, color, HERO, k)
        val bar = Prefs.wdStyle(ctx) == 1
        if (bar) {
            rv.setViewVisibility(R.id.dt_w, View.GONE)
            rv.setViewVisibility(R.id.wd_bar, View.VISIBLE)
            val on = onFill(color)
            for (d in 1..7) {
                val today = d == c.weekdayIdx
                rv.setTextColor(WD_TEXT[d - 1], if (today) on else soft)
                rv.setTextViewTextSize(WD_TEXT[d - 1], TypedValue.COMPLEX_UNIT_SP, roundHalf(CAPTION * k))
                rv.setViewVisibility(WD_PILL[d - 1], if (today) View.VISIBLE else View.GONE)
                if (today) rv.setInt(WD_PILL[d - 1], "setColorFilter", opaque(color))
            }
        } else {
            rv.setViewVisibility(R.id.wd_bar, View.GONE)
            put(rv, R.id.dt_w, c.dtW, color, HEADING, k)
        }

        // Trên-phải: biểu tượng + nhiệt độ lớn, mô tả, gió, UV, AQI, địa điểm.
        rv.setImageViewResource(R.id.wx_icon, c.wxIcon)
        rv.setInt(R.id.wx_icon, "setColorFilter", color)
        setBox(rv, R.id.wx_icon, ICON_DP * s, ICON_DP * s)
        put(rv, R.id.wx1, c.wx1, color, DISPLAY, k)
        put(rv, R.id.wx1b, c.wx1b, color, BODY, k)
        put(rv, R.id.wx2, c.wx2, color, BODY, k)
        put(rv, R.id.wx3, c.wx3, color, BODY, k)
        put(rv, R.id.wx4, c.wx4, color, BODY, k)
        put(rv, R.id.wx5, c.wx5, soft, CAPTION, k)

        // Dưới-trái: âm lịch, hoàng đạo/hắc đạo, tiết khí.
        put(rv, R.id.lu0, c.lu0, soft, CAPTION, k)
        put(rv, R.id.lu1, c.lu1, color, TITLE, k)
        put(rv, R.id.lu2, c.lu2, color, BODY, k)
        if (c.hdOn) {
            rv.setViewVisibility(R.id.row_hd, View.VISIBLE)
            rv.setImageViewResource(R.id.lu_dot, if (c.hdGood) R.drawable.dot_red else R.drawable.dot_black)
            setBox(rv, R.id.lu_dot, DOT_DP * s, DOT_DP * s)
            put(rv, R.id.lu3, c.lu3, color, BODY, k)
            put(rv, R.id.lu3b, c.lu3b, soft, CAPTION, k)
        } else {
            rv.setViewVisibility(R.id.row_hd, View.GONE)
        }
        put(rv, R.id.lu4, c.lu4, color, BODY, k)
        put(rv, R.id.lu5, c.lu5, soft, CAPTION, k)

        // Dưới-phải: sự kiện.
        put(rv, R.id.ev0, c.ev0, soft, CAPTION, k)
        for (i in EV_IDS.indices) put(rv, EV_IDS[i], c.ev.getOrNull(i), color, BODY, k)

        // Đường kẻ chia ô.
        val line = opaque(color)
        for (id in intArrayOf(R.id.dvv1, R.id.dvv2, R.id.dvh)) {
            rv.setInt(id, "setColorFilter", line)
            rv.setInt(id, "setImageAlpha", 70)
        }

        // Ô tắt thì ẩn nhưng giữ chỗ để cột còn lại không dồn sang bên; cả hàng dưới tắt thì bỏ hàng.
        rv.setViewVisibility(R.id.box_wx, if (c.wxOn) View.VISIBLE else View.INVISIBLE)
        rv.setViewVisibility(R.id.box_lu, if (c.luOn) View.VISIBLE else View.INVISIBLE)
        rv.setViewVisibility(R.id.box_ev, if (c.calOn) View.VISIBLE else View.INVISIBLE)
        val row2 = if (c.luOn || c.calOn) View.VISIBLE else View.GONE
        rv.setViewVisibility(R.id.row2, row2)
        rv.setViewVisibility(R.id.dvh, row2)
    }

    // ---------- PendingIntent ----------

    private fun openAppPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx,
            11,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun calendarPi(ctx: Context): PendingIntent {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, 14, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    // ---------- Widget màn hình chính ----------

    /**
     * widthDp/heightDp: kích thước widget do launcher báo (dọc: MIN_WIDTH và MAX_HEIGHT); <= 0 thì dùng cỡ chuẩn.
     * Bấm ô ngày: mở app. Bấm ô sự kiện: mở Lịch. Bấm chỗ khác: làm mới thời tiết và sự kiện.
     */
    fun widgetViews(ctx: Context, widthDp: Int, heightDp: Int): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val color = Prefs.textColor(ctx)
        val rv = RemoteViews(ctx.packageName, f.widget(shadowGroup(color)))
        val padDp = Prefs.padDp(ctx)

        val w = if (widthDp > 0) widthDp.toFloat() else 360f
        val h = if (heightDp > 0) heightDp.toFloat() else f.refHeightDp.toFloat()
        fill(ctx, rv, cells(ctx, true), color, scaleFor(ctx, w, h, padDp.toFloat()))

        val pad = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, padDp.toFloat(), ctx.resources.displayMetrics).toInt()
        rv.setViewPadding(R.id.content, pad, pad, pad, pad)

        rv.setOnClickPendingIntent(R.id.content, Updater.refreshPi(ctx))
        rv.setOnClickPendingIntent(R.id.box_dt, openAppPi(ctx))
        rv.setOnClickPendingIntent(R.id.box_ev, calendarPi(ctx))

        val bg = Prefs.bgColor(ctx)
        rv.setImageViewResource(R.id.bg, CORNER_DRAWABLES[Prefs.corner(ctx)])
        rv.setInt(R.id.bg, "setColorFilter", opaque(bg))
        rv.setInt(R.id.bg, "setImageAlpha", (Prefs.bgAlpha(ctx) * 255 / 100).coerceIn(0, 255))
        return rv
    }

    // ---------- Khối thông tin trên ảnh nền khóa ----------

    /** Cùng bố cục 2x2 với widget, không nền riêng (nền do LockWallpaper vẽ). widthDp: bề rộng khối. */
    fun wallpaperViews(ctx: Context, widthDp: Float): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val color = Prefs.textColor(ctx)
        val rv = RemoteViews(ctx.packageName, f.wall(shadowGroup(color)))
        fill(ctx, rv, cells(ctx), color, snap((widthDp / REF_INNER_W).coerceIn(0.7f, 1.8f)))
        return rv
    }

    // ---------- Thẻ màn hình khóa ----------

    private fun isNight(ctx: Context): Boolean {
        val m = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return m == Configuration.UI_MODE_NIGHT_YES
    }

    fun lockTextColor(ctx: Context): Int {
        return when (Prefs.lockColor(ctx)) {
            1 -> Color.WHITE
            2 -> Color.BLACK
            else -> if (isNight(ctx)) Color.WHITE else Color.parseColor("#E6000000")
        }
    }

    /**
     * Thẻ thông báo trên màn hình khóa.
     * Mở rộng: cùng bố cục 2x2, thu nhỏ 0,9 vì thẻ hẹp hơn widget. Thu gọn: hai cột, mỗi cột hai dòng.
     */
    fun notifViews(ctx: Context, expanded: Boolean): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val color = lockTextColor(ctx)
        val g = shadowGroup(color)
        val c = cells(ctx)
        if (expanded) {
            val rv = RemoteViews(ctx.packageName, f.notifBig(g))
            fill(ctx, rv, c, color, 0.9f)
            return rv
        }

        val rv = RemoteViews(ctx.packageName, f.notifSmall(g))
        val soft = dim(color)
        val today = LocalDate.now()
        put(rv, R.id.dt1, c.dtW + String.format(Locale.US, ", %02d/%02d", today.dayOfMonth, today.monthValue), color, BODY, 1f)

        val lu = if (c.luOn) {
            join(listOf(c.lu1?.let { "Âm $it" }, if (c.hdOn) c.lu3 else null))
        } else null
        put(rv, R.id.lu1, lu, soft, CAPTION, 1f)

        if (c.wxOn) {
            put(rv, R.id.wx1, join(listOf(c.wx1, c.wx1b)), color, BODY, 1f)
            put(rv, R.id.wx2, c.wx2, soft, CAPTION, 1f)
        } else {
            rv.setViewVisibility(R.id.wx1, View.GONE)
            rv.setViewVisibility(R.id.wx2, View.GONE)
        }
        return rv
    }
}
