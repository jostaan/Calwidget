package vn.xin.clockwidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.provider.AlarmClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/**
 * Dựng RemoteViews cho widget, thẻ khóa và khối thông tin trên ảnh nền khóa.
 *
 * Bố cục 2 cột x 2 hàng:
 *   trái:  [đồng hồ]            / [thời tiết: nhiệt độ, ẩm, gió, UV, không khí]
 *   phải:  [thứ, ngày tháng]    / [âm lịch, hoàng đạo]
 *
 * Hệ chữ (cố định, không tự co): 5 vai trò, cỡ chuẩn ở widget rộng 360 dp.
 *   Hiển thị 50 sp (đồng hồ) · Tiêu đề 24 sp (thứ, nhiệt độ) · Đề mục 15 sp (ngày, âm lịch)
 *   Nội dung 13 sp (ẩm, gió, UV, AQI, can chi, hoàng đạo) · Chú thích 12 sp (mô tả, năm, giờ hoàng đạo, sự kiện)
 * Cỡ thực = cỡ chuẩn x hệ số tỉ lệ, hệ số tính một lần từ kích thước widget (xem [scaleFor]).
 * Phông và chiều cao tham chiếu theo từng bộ phông ở [FontCatalog].
 */
object Renderer {
    private const val DISPLAY = 50f
    private const val TITLE = 24f
    private const val HEADING = 15f
    private const val BODY = 13f
    private const val CAPTION = 12f

    /** Bề rộng nội dung chuẩn: widget 360 dp trừ lề 6 dp hai bên. */
    private const val REF_INNER_W = 348f
    private const val REF_PAD = 12f
    private const val SCALE_STEP = 0.05f

    private val CORNER_DRAWABLES = intArrayOf(R.drawable.bg_r0, R.drawable.bg_r12, R.drawable.bg_r22, R.drawable.bg_r32)

    /** Nội dung từng ô. null = ẩn dòng đó. */
    class Cells {
        var dt1: String? = null
        var dt2: String? = null
        var ev: String? = null
        var wx1: String? = null
        var wx1b: String? = null
        var wx2: String? = null
        var wx3: String? = null
        var wx4: String? = null
        var lu1: String? = null
        var lu1b: String? = null
        var lu2: String? = null
        var lu3: String? = null
        var lu4: String? = null
        var weatherOn: Boolean = true
        var lunarOn: Boolean = true
    }

    private fun join(parts: List<String>): String? {
        val p = parts.filter { it.isNotEmpty() }
        return if (p.isEmpty()) null else p.joinToString(" · ")
    }

    private fun uvShort(uv: Double): String = when {
        uv < 3 -> "thấp"
        uv < 6 -> "vừa"
        uv < 8 -> "cao"
        uv < 11 -> "rất cao"
        else -> "cực cao"
    }

    private fun aqiShort(aqi: Int): String = when {
        aqi <= 50 -> "tốt"
        aqi <= 100 -> "vừa"
        aqi <= 150 -> "kém"
        aqi <= 200 -> "xấu"
        aqi <= 300 -> "rất xấu"
        else -> "nguy hại"
    }

    // ---------- Nội dung các ô ----------

    private fun dateCells(ctx: Context, today: LocalDate, c: Cells) {
        c.dt1 = VnText.weekday(today.dayOfWeek)
        c.dt2 = if (Prefs.longDate(ctx)) {
            "${today.dayOfMonth} tháng ${today.monthValue}, ${today.year}"
        } else {
            String.format(Locale.US, "%02d/%02d/%d", today.dayOfMonth, today.monthValue, today.year)
        }
    }

    private fun lunarCells(ctx: Context, today: LocalDate, c: Cells) {
        val showLunar = Prefs.showLunar(ctx)
        val showAlmanac = Prefs.showAlmanac(ctx)
        c.lunarOn = showLunar || showAlmanac
        val lunar = LunarCalendar.fromSolar(today.dayOfMonth, today.monthValue, today.year)

        if (showLunar) {
            val lm = if (lunar.leap) "${lunar.month} nhuận" else "${lunar.month}"
            c.lu1 = "Âm lịch ${lunar.day}/$lm"
            if (Prefs.lunarDetail(ctx)) {
                c.lu1b = lunar.yearCanChi()
                c.lu2 = "Ngày ${lunar.dayCanChi()}"
            }
        }
        if (showAlmanac) {
            c.lu3 = Almanac.dayLabel(lunar.month, lunar.jd).replace(" (", " · ").removeSuffix(")")
            c.lu4 = "Giờ hoàng đạo: " + Almanac.goodHours(lunar.jd, false)
        }
        if (Prefs.showEvents(ctx)) {
            val ev = ArrayList<String>(VnText.holidays(today))
            val term = LunarCalendar.solarTermStartingOn(lunar.jd)
            if (term != null) ev.add("Tiết $term")
            c.ev = join(ev)
        }
    }

    private fun weatherCells(ctx: Context, c: Cells) {
        c.weatherOn = Prefs.showWeather(ctx)
        if (!c.weatherOn) return
        val w = WeatherRepo.load(ctx)
        if (w == null) {
            c.wx1 = "--°C"
            c.wx1b = "chưa có dữ liệu"
            c.wx2 = "Mở app, bấm Lấy thời tiết"
            return
        }
        c.wx1 = "${Math.round(w.tempC)}°C"
        c.wx1b = if (WeatherRepo.ageMinutes(ctx) > 90) {
            "cập nhật " + SimpleDateFormat("HH:mm", Locale.US).format(Date(w.fetchedAt))
        } else {
            VnText.weatherDesc(w.code)
        }

        val l2 = ArrayList<String>()
        if (w.humidity >= 0) l2.add("Ẩm ${w.humidity}%")
        if (!w.windKmh.isNaN()) l2.add("Gió ${Math.round(w.windKmh)} km/h")
        c.wx2 = join(l2)

        // UV là chỉ số cao nhất trong ngày (Open-Meteo daily), nên ghi rõ "đỉnh".
        if (!w.uvMax.isNaN()) c.wx3 = "UV đỉnh ${Math.round(w.uvMax)} (${uvShort(w.uvMax)})"
        if (w.aqi >= 0) c.wx4 = "AQI ${w.aqi} (${aqiShort(w.aqi)})"
    }

    fun cells(ctx: Context): Cells {
        val c = Cells()
        val today = LocalDate.now()
        dateCells(ctx, today, c)
        lunarCells(ctx, today, c)
        weatherCells(ctx, c)
        return c
    }

    /** Văn bản thuần cho kiểu thẻ khóa "văn bản đơn giản". */
    fun plainLines(ctx: Context): List<String> {
        val c = cells(ctx)
        val out = ArrayList<String>()
        out.add(c.dt1 + ", " + c.dt2)
        join(listOfNotNull(c.lu1, c.lu1b, c.lu2))?.let { out.add(it) }
        c.lu3?.let { out.add(it) }
        c.lu4?.let { out.add(it) }
        c.ev?.let { out.add(it) }
        if (c.weatherOn) {
            join(listOfNotNull(c.wx1, c.wx1b))?.let { out.add(it) }
            c.wx2?.let { out.add(it) }
            join(listOfNotNull(c.wx3, c.wx4))?.let { out.add(it) }
            out.add(Prefs.locName(ctx))
        }
        return out
    }

    // ---------- Hệ số tỉ lệ ----------

    private fun fontScale(ctx: Context): Float {
        val f = ctx.resources.configuration.fontScale
        return if (f > 0.5f) f else 1f
    }

    /**
     * Hệ số tỉ lệ của hệ chữ so với widget chuẩn: nhỏ hơn trong hai tỉ lệ rộng và cao, để cả hai chiều đều vừa.
     * Làm tròn xuống bội của 0,05 và giới hạn 0,7 đến 1,8: cùng một kích thước widget luôn ra cùng một cỡ chữ.
     */
    fun scaleFor(ctx: Context, widthDp: Float, heightDp: Float, padDp: Float): Float {
        val f = FontCatalog.get(Prefs.font(ctx))
        val sw = (widthDp - 2 * padDp) / REF_INNER_W
        val sh = (heightDp - 2 * padDp) / (f.refHeightDp - REF_PAD)
        val s = Math.min(sw, sh).coerceIn(0.7f, 1.8f)
        return Math.floor((s / SCALE_STEP).toDouble()).toFloat() * SCALE_STEP
    }

    // ---------- Thao tác với RemoteViews ----------

    private fun dim(color: Int): Int =
        Color.argb((Color.alpha(color) * 0.82f).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    private fun roundHalf(v: Float): Float = Math.round(v * 2f) / 2f

    private fun put(rv: RemoteViews, id: Int, text: String?, color: Int, roleSp: Float, k: Float) {
        if (text.isNullOrEmpty()) {
            rv.setViewVisibility(id, View.GONE)
        } else {
            rv.setViewVisibility(id, View.VISIBLE)
            rv.setTextViewText(id, text)
            rv.setTextColor(id, color)
            rv.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, roundHalf(roleSp * k))
        }
    }

    private fun setClock(ctx: Context, rv: RemoteViews, color: Int, sizeSp: Float?) {
        val fmt = if (Prefs.is24h(ctx)) "HH:mm" else "h:mm"
        rv.setTextColor(R.id.clock, color)
        rv.setCharSequence(R.id.clock, "setFormat24Hour", fmt)
        rv.setCharSequence(R.id.clock, "setFormat12Hour", fmt)
        if (sizeSp != null) rv.setTextViewTextSize(R.id.clock, TypedValue.COMPLEX_UNIT_SP, sizeSp)
    }

    /**
     * Điền nội dung vào bố cục 2x2 (widget, thẻ khóa mở rộng) hoặc khối ảnh nền (không có đồng hồ, không có hàng).
     * grid = true: có row1/row2; ô tắt thì ẩn nhưng giữ chỗ để cột phải không dồn sang trái.
     */
    private fun fill(ctx: Context, rv: RemoteViews, c: Cells, color: Int, s: Float, grid: Boolean) {
        val soft = dim(color)
        val k = s / fontScale(ctx)
        if (grid) setClock(ctx, rv, color, roundHalf(DISPLAY * k))

        put(rv, R.id.dt1, c.dt1, color, TITLE, k)
        put(rv, R.id.dt2, c.dt2, soft, HEADING, k)
        put(rv, R.id.ev, c.ev, soft, CAPTION, k)

        put(rv, R.id.wx1, c.wx1, color, TITLE, k)
        put(rv, R.id.wx1b, c.wx1b, soft, CAPTION, k)
        put(rv, R.id.wx2, c.wx2, soft, BODY, k)
        put(rv, R.id.wx3, c.wx3, soft, BODY, k)
        put(rv, R.id.wx4, c.wx4, soft, BODY, k)

        put(rv, R.id.lu1, c.lu1, color, HEADING, k)
        put(rv, R.id.lu1b, c.lu1b, soft, CAPTION, k)
        put(rv, R.id.lu2, c.lu2, soft, BODY, k)
        put(rv, R.id.lu3, c.lu3, soft, BODY, k)
        put(rv, R.id.lu4, c.lu4, soft, CAPTION, k)

        val off = if (grid) View.INVISIBLE else View.GONE
        rv.setViewVisibility(R.id.box_wx, if (c.weatherOn) View.VISIBLE else off)
        rv.setViewVisibility(R.id.box_lu, if (c.lunarOn) View.VISIBLE else off)
        if (grid) rv.setViewVisibility(R.id.row2, if (c.weatherOn || c.lunarOn) View.VISIBLE else View.GONE)
    }

    // ---------- PendingIntent ----------

    private fun openAppPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx,
            11,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun alarmsPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx,
            12,
            Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // ---------- Widget màn hình chính ----------

    /** widthDp/heightDp: kích thước widget do launcher báo (dọc: MIN_WIDTH và MAX_HEIGHT); <= 0 thì dùng cỡ chuẩn. */
    fun widgetViews(ctx: Context, widthDp: Int, heightDp: Int): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val rv = RemoteViews(ctx.packageName, f.widgetLayout)
        val color = Prefs.textColor(ctx)
        val padDp = Prefs.padDp(ctx)

        val w = if (widthDp > 0) widthDp.toFloat() else 360f
        val h = if (heightDp > 0) heightDp.toFloat() else f.refHeightDp.toFloat()
        fill(ctx, rv, cells(ctx), color, scaleFor(ctx, w, h, padDp.toFloat()), true)

        val pad = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, padDp.toFloat(), ctx.resources.displayMetrics).toInt()
        rv.setViewPadding(R.id.content, pad, pad, pad, pad)

        rv.setOnClickPendingIntent(R.id.clock, alarmsPi(ctx))
        rv.setOnClickPendingIntent(R.id.content, openAppPi(ctx))

        val bg = Prefs.bgColor(ctx)
        rv.setImageViewResource(R.id.bg, CORNER_DRAWABLES[Prefs.corner(ctx)])
        rv.setInt(R.id.bg, "setColorFilter", Color.rgb(Color.red(bg), Color.green(bg), Color.blue(bg)))
        rv.setInt(R.id.bg, "setImageAlpha", (Prefs.bgAlpha(ctx) * 255 / 100).coerceIn(0, 255))
        return rv
    }

    // ---------- Khối thông tin trên ảnh nền khóa ----------

    /** Bố cục 2 cột không có đồng hồ (đồng hồ là của màn hình khóa hệ thống). widthDp: bề rộng khối. */
    fun wallpaperViews(ctx: Context, widthDp: Float): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val rv = RemoteViews(ctx.packageName, f.wallLayout)
        val s = (widthDp / 360f).coerceIn(0.7f, 1.8f)
        fill(ctx, rv, cells(ctx), Prefs.textColor(ctx), Math.floor((s / SCALE_STEP).toDouble()).toFloat() * SCALE_STEP, false)
        return rv
    }

    // ---------- Thẻ màn hình khóa ----------

    private fun isNight(ctx: Context): Boolean {
        val m = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return m == Configuration.UI_MODE_NIGHT_YES
    }

    fun lockTextColor(ctx: Context): Int {
        return when (Prefs.lockColor(ctx)) {
            1 -> Color.WHITE
            2 -> Color.BLACK
            else -> if (isNight(ctx)) Color.WHITE else Color.parseColor("#E6000000")
        }
    }

    /**
     * Thẻ thông báo trên màn hình khóa.
     * Mở rộng: cùng bố cục 2x2 như widget, hệ số tỉ lệ 1. Thu gọn: một hàng (giờ | ngày, âm lịch | thời tiết).
     */
    fun notifViews(ctx: Context, expanded: Boolean): RemoteViews {
        val f = FontCatalog.get(Prefs.font(ctx))
        val color = lockTextColor(ctx)
        val c = cells(ctx)
        if (expanded) {
            val rv = RemoteViews(ctx.packageName, f.notifBigLayout)
            fill(ctx, rv, c, color, 1f, true)
            return rv
        }

        val rv = RemoteViews(ctx.packageName, f.notifLayout)
        val soft = dim(color)
        rv.setTextColor(R.id.clock, color)
        val fmt = if (Prefs.is24h(ctx)) "HH:mm" else "h:mm"
        rv.setCharSequence(R.id.clock, "setFormat24Hour", fmt)
        rv.setCharSequence(R.id.clock, "setFormat12Hour", fmt)

        val today = LocalDate.now()
        rv.setTextViewText(R.id.dt1, c.dt1 + String.format(Locale.US, ", %02d/%02d", today.dayOfMonth, today.monthValue))
        rv.setTextColor(R.id.dt1, color)

        var lu: String? = null
        if (c.lunarOn) {
            val lunar = LunarCalendar.fromSolar(today.dayOfMonth, today.monthValue, today.year)
            val lm = if (lunar.leap) "${lunar.month} nhuận" else "${lunar.month}"
            val parts = ArrayList<String>()
            if (Prefs.showLunar(ctx)) parts.add("Âm ${lunar.day}/$lm")
            if (Prefs.showAlmanac(ctx)) parts.add(if (Almanac.isGoodDay(lunar.month, lunar.jd)) "Hoàng đạo" else "Hắc đạo")
            lu = join(parts)
        }
        if (lu == null) rv.setViewVisibility(R.id.lu1, View.GONE) else {
            rv.setViewVisibility(R.id.lu1, View.VISIBLE)
            rv.setTextViewText(R.id.lu1, lu)
            rv.setTextColor(R.id.lu1, soft)
        }

        if (c.weatherOn) {
            rv.setViewVisibility(R.id.wx1, View.VISIBLE)
            rv.setViewVisibility(R.id.wx2, View.VISIBLE)
            rv.setTextViewText(R.id.wx1, join(listOfNotNull(c.wx1, c.wx1b)) ?: "")
            rv.setTextColor(R.id.wx1, color)
            rv.setTextViewText(R.id.wx2, c.wx2 ?: "")
            rv.setTextColor(R.id.wx2, soft)
        } else {
            rv.setViewVisibility(R.id.wx1, View.GONE)
            rv.setViewVisibility(R.id.wx2, View.GONE)
        }
        return rv
    }
}
