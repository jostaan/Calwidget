# Đồng hồ · Lịch · Thời tiết (widget cho Redmi K70 / HyperOS 3)

Gói `vn.xin.clockwidget`. Hai phần hiển thị:

1. **Widget màn hình chính** (4×2, đổi kích thước được), chia **2 cột × 2 hàng**:
   - Trái trên: đồng hồ chạy thật (TextClock), chữ lớn, đậm.
   - Trái dưới: thời tiết Quận 11: nhiệt độ + mô tả, độ ẩm, gió, UV (chỉ số cao nhất trong ngày), chất lượng không khí (US AQI).
   - Phải trên: thứ, ngày tháng (kèm ngày lễ/tiết khí nếu có).
   - Phải dưới: âm lịch + can chi năm, can chi ngày, ngày hoàng đạo/hắc đạo (kèm sao), giờ hoàng đạo.
   Cỡ chữ cố định theo từng vai trò, nhân hệ số tính từ kích thước widget (kéo cao/rộng hơn thì chữ to hơn); xem mục hệ chữ bên dưới. Lề trong chỉnh 0–24 dp (mặc định 6), bo góc 4 mức. Lề do launcher HyperOS đặt quanh widget thì app không đổi được.
2. **Màn hình khóa** (tùy chọn, hai cách, xem mục Giới hạn): ảnh nền khóa có thông tin, và thẻ thông báo ghim. Thẻ mở rộng ra thì cùng bố cục 2×2 như widget; thu gọn là một hàng (giờ | ngày, âm lịch | thời tiết).

## Giới hạn cần biết

- **Widget của app bên thứ ba không lên được màn hình khóa HyperOS 3.** Một bài báo ngày 12/01/2026 (touchit.sk) xác nhận Android 16 có widget màn hình khóa nhưng điện thoại Xiaomi/Redmi/POCO chưa có; HyperOS 4 mới là dự kiến, chưa được xác nhận. Hai cách thay thế trong app (đều dùng API chuẩn, chưa kiểm chứng trên HyperOS 3):
  1. **Ảnh nền khóa có thông tin**: app tự vẽ ảnh nền khóa (ảnh bạn chọn hoặc nền màu) kèm khối thời tiết, ngày, âm lịch, hoàng đạo, đặt bằng `WallpaperManager.setBitmap(..., FLAG_LOCK)`. Giờ không nằm trong ảnh (ảnh tĩnh sẽ sai giờ); giờ là của màn hình khóa hệ thống. Ảnh chỉ đặt lại khi nội dung đổi. Nếu HyperOS không áp ảnh: tắt Wallpaper Carousel và hiệu ứng chiều sâu của màn hình khóa.
  2. **Thẻ thông báo ghim**: kênh `lockcard_v2` (độ quan trọng mặc định, không âm thanh/rung) để không bị xếp vào nhóm "yên lặng". Cần cho phép app hiện thông báo trên màn hình khóa.
  Cách theme Xiaomi (MAML, dựng bằng Theme Editor trên máy tính) không được dùng: cần máy tính và USB debugging, chỉ có font hệ thống, thời tiết lấy từ app Thời tiết của Xiaomi và không có lịch hoàng đạo.
- Thẻ khóa phụ thuộc cài đặt hiện thông báo trên màn hình khóa. Từ Android 14 bạn vuốt bỏ được thẻ; thẻ hiện lại ở lần cập nhật kế tiếp.
- Hệ chữ có chủ đích: 6 bộ phông (Be Vietnam Pro, Montserrat, Nunito, Lora, Oswald + Be Vietnam Pro, Roboto Mono + Be Vietnam Pro), đều đủ dấu tiếng Việt (đã kiểm từng ký tự) và đọc rõ ở cỡ nhỏ; bỏ các phông chữ viết tay và nét mảnh. Mỗi bộ có 3 vai trò: đồng hồ, tiêu đề (đậm), nội dung (thường). Cỡ chuẩn (sp, ở widget rộng 360 dp): hiển thị 50, tiêu đề 24, đề mục 15, nội dung 13, chú thích 12. Cỡ thực = cỡ chuẩn x hệ số tỉ lệ = min(rộng/348, cao/chiều cao tham chiếu của bộ phông), làm tròn xuống bội 0,05, trong khoảng 0,7–1,8, chia cho hệ số cỡ chữ hệ thống. Chiều cao tham chiếu (162–178 dp) tính từ số liệu dòng của chính phông. Độ vừa của chuỗi dài nhất (Chủ Nhật, ẩm 100%, gió 100 km/h, AQI 301, giờ hoàng đạo) đã đo bằng phông thật ở cột rộng 168 dp. Không dùng autoSize. Thêm phông mới cần build lại; app không tải phông lúc chạy.
- Thời tiết: Open-Meteo (không cần khóa, chỉ dùng phi thương mại). AQI là mô hình ~45 km, không phải số liệu trạm đo.
- UV hiển thị là chỉ số cao nhất trong ngày (Open-Meteo `uv_index_max`), không phải UV tức thời; vì thế ghi "UV đỉnh". Ngày/giờ hoàng đạo tính theo bảng lịch vạn niên phổ biến (12 thần, 6 giờ hoàng đạo); các sách lịch có thể khác nhau ở một số cách chia.
- Chưa chạy thử trên máy thật. Mã Kotlin đã được kiểm tra kiểu với Android API 33; tài nguyên và Gradle chỉ được xác nhận khi chạy workflow.

## Build bằng điện thoại (GitHub Actions)

Dùng chung repo đã có, không tạo repo mới.

1. Vào repo → **Add file → Upload files**, tải lên 2 tệp:
   - `lockscreen-widget.zip` (thư mục gốc repo)
   - `.github/workflows/build-widget.yml` (nếu giao diện không cho tải thư mục, chọn **Create new file**, gõ tên `.github/workflows/build-widget.yml` rồi dán nội dung)
2. Tab **Actions → Build Clock Widget APK → Run workflow**.
3. Xong: tab **Releases** → bản `widget-N` → tải `ClockWidget.apk` và cài.

Cập nhật sau này: chỉ tải đè `lockscreen-widget.zip`, chạy lại workflow. Cùng chữ ký nên cài đè không mất cấu hình.

## Cài đặt trên HyperOS để chạy ổn định

- Cài đặt → Ứng dụng → Đồng hồ Lịch Thời tiết → **Tự khởi động**: Bật.
- Tiết kiệm pin: **Không hạn chế**.
- Khóa app trong màn hình đa nhiệm (nhấn giữ thẻ app → biểu tượng khóa).
- Thẻ khóa: Cài đặt → Thông báo → Màn hình khóa → hiện nội dung; kênh "Thẻ màn hình khóa" để bật.
- Trong app có nút mở sẵn các màn hình trên.

## Cơ chế cập nhật

- Đồng hồ: TextClock tự chạy, không tốn pin cập nhật.
- Thời tiết: ba đường độc lập, đường nào chạy cũng đủ: (1) JobScheduler ~30 phút, (2) báo thức gần đúng ~30 phút tự đặt lại, (3) lệnh cập nhật định kỳ của widget (30 phút). Dữ liệu lưu sẵn, mất mạng vẫn hiển thị (ghi chú giờ cập nhật nếu cũ hơn 90 phút). Nếu chưa lấy được, cột phải ghi rõ lý do (ví dụ HTTP 403, UnknownHostException).
- Mọi bước lập lịch và vẽ đều bọc try/catch riêng và ghi lỗi vào bản ghi trong app; vẽ widget luôn chạy trước bước lập lịch.
- Ngày/âm lịch: báo thức sau 00:00 mỗi ngày, cộng thêm khi đổi giờ, múi giờ, khởi động lại.
- Không dùng foreground service.

## Cấu trúc

- `LunarCalendar.java`: âm lịch (thuật toán Hồ Ngọc Đức, UTC+7), can chi, 24 tiết khí.
- `VnText.java`: thứ, mô tả thời tiết, UV/AQI, ngày lễ.
- `Almanac.java`: ngày hoàng đạo/hắc đạo (12 thần) và 6 giờ hoàng đạo.
- `WeatherRepo.kt`, `Renderer.kt` (TextView thuần, không vẽ chữ vào ảnh, không emoji), `Updater.kt`, `LockCard.kt`, `Receivers.kt`, `MainActivity.kt`.
- `LockWallpaper.kt`: vẽ và đặt ảnh nền khóa (luồng riêng có Looper, bỏ qua nếu nội dung không đổi), `CrashLog.kt` (chỉ ghi logcat).
- `res/font`: TTF; `res/layout/w_*` (widget), `nb_*` (thẻ khóa mở rộng), `n_*` (thẻ khóa thu gọn), `wp_*` (khối trên ảnh nền khóa) sinh theo từng bộ phông vì RemoteViews không đổi phông lúc chạy.
- Icon: `res/drawable/ic_launcher_*` (adaptive, có lớp đơn sắc cho biểu tượng theo chủ đề), `ic_stat_clock` (thông báo), `ic_shortcut_diag`.
