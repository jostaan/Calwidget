# Lịch · Thời tiết · Sự kiện (widget cho Redmi K70 / HyperOS 3)

Gói `vn.xin.clockwidget`, bản 1.5. Không vẽ đồng hồ: màn hình khóa của hệ thống đã có giờ.

## Bố cục 2 cột × 2 hàng

| | Cột trái | Cột phải |
|---|---|---|
| **Hàng trên** | **Ngày dương**: tháng (Tháng Mười Một), ngày cỡ lớn (27), thứ (chữ "Thứ Sáu" hoặc thanh 7 ô T2…CN, ô hôm nay nổi bật; chọn trong app) | **Thời tiết** (Đầm Sen): biểu tượng + **nhiệt độ cỡ lớn**, mô tả, hướng và tốc độ gió, UV đỉnh trong ngày, AQI, tên địa điểm + độ ẩm |
| **Hàng dưới** | **Âm lịch**: ngày/tháng âm, can chi năm và ngày, chấm đỏ = hoàng đạo (kèm sao), chấm đen = hắc đạo, tiết khí đang có hiệu lực và tiết kế tiếp | **Sự kiện**: tối đa 5 sự kiện gần nhất trong 60 ngày tới, dạng `27/10 - Về quê thăm ngoại` |

Cùng bố cục áp dụng cho widget màn hình chính, khối thông tin trên ảnh nền khóa và thẻ thông báo khóa mở rộng (thẻ thu gọn là một hàng ngày | âm lịch | thời tiết).

Chạm vào widget: chạm ô ngày mở app, chạm ô sự kiện mở Lịch, chạm chỗ khác gửi lệnh làm mới thời tiết và sự kiện (widget hiện "Đang cập nhật…" trong lúc chờ).

Widget cao: đặt cỡ khoảng 4×3 ô trở lên. Nếu đặt thấp hơn, chữ tự nhỏ lại (tối thiểu 0,7 lần); thấp quá thì nội dung bị cắt.

## Hệ chữ

6 vai trò, cố định, cỡ chuẩn (sp) ở widget rộng 360 dp: **ngày 60 · nhiệt độ 40 · ngày âm 24 · tháng và thứ 16 · nội dung 13 · chú thích 12**. Cùng loại thông tin luôn cùng cỡ, cùng phông và cùng độ đậm. Cỡ thực = cỡ chuẩn × hệ số tỉ lệ = min(rộng/348, cao/chiều cao tham chiếu của bộ phông), làm tròn xuống bội 0,05, trong khoảng 0,7–1,8, chia cho hệ số cỡ chữ hệ thống. Chiều cao tham chiếu (264–292 dp) tính từ số liệu dòng của chính phông. Chiều rộng các chuỗi dài nhất đã đo bằng phông thật: cột trái 48%, cột phải 52% (cột phải rộng hơn để dòng sự kiện dài ít bị cắt). Thêm phông mới cần build lại.

6 bộ phông: Be Vietnam Pro, Montserrat, Nunito, Lora, Oswald (số lớn) + Be Vietnam Pro, Roboto Mono (số lớn) + Be Vietnam Pro. Mỗi bộ có 3 phông: số lớn (ngày, nhiệt độ, ngày âm), tiêu đề (tháng, thứ), nội dung.

**Bóng chữ**: mọi chữ có bóng nhẹ. Chữ sáng (độ sáng ≥ 0,45) dùng bóng đen lệch xuống 1 dp, mờ 3 dp. Chữ tối dùng quầng sáng mờ 2 dp, vì bóng đen không nhìn thấy trên chữ tối. RemoteViews không đổi được bóng chữ lúc chạy nên mỗi bố cục sinh 2 biến thể và app chọn theo màu chữ.

**Màu chữ**: ô nhập mã #RRGGBB và lưới 16 màu mẫu. 10 màu thêm: `622599`, `0054a0`, `aaba0a`, `dd7500`, `e23d28`, `3d8e33`, `3399ff`, `ff3399`, `fcd116`, `999999`. Màu tối (`622599`, `0054a0`, `3d8e33`, `e23d28`) khó đọc trên nền widget tối; đổi màu nền widget sang sáng hoặc giảm độ đậm nền khi dùng.

## Giới hạn cần biết

- **Widget của app bên thứ ba không lên được màn hình khóa HyperOS 3.** Hai cách thay thế trong app (đều dùng API chuẩn, chưa kiểm chứng trên HyperOS 3):
  1. **Ảnh nền khóa có thông tin**: app tự vẽ ảnh nền khóa (ảnh bạn chọn hoặc nền màu) kèm khối thông tin 2×2, đặt bằng `WallpaperManager.setBitmap(..., FLAG_LOCK)`. Ảnh chỉ đặt lại khi nội dung đổi. Nếu HyperOS không áp ảnh: tắt Wallpaper Carousel và hiệu ứng chiều sâu của màn hình khóa.
  2. **Thẻ thông báo ghim**: kênh `lockcard_v2`. Cần cho phép app hiện thông báo trên màn hình khóa.
- **Sự kiện đọc từ lịch trong máy**, không gọi API Google và không cần đăng nhập Google. Google Calendar hiện ở đó khi tài khoản Google bật đồng bộ Lịch (Cài đặt → Tài khoản → Google → Đồng bộ tài khoản → Lịch). Đây là bản sao trên máy, không phải thời gian thực: sự kiện tạo trên nơi khác chỉ hiện sau khi máy đồng bộ xong và widget được làm mới (chạm widget). Cần cấp quyền "Lịch" (nút trong app). Có tùy chọn chỉ lấy lịch tài khoản Google và tùy chọn thêm ngày lễ/Rằm/mùng 1 có sẵn trong app (mặc định tắt vì có thể trùng với lịch ngày lễ bạn đã đăng ký). Sự kiện đã kết thúc và sự kiện bạn đã từ chối không hiện. Sự kiện cả ngày và sự kiện đang diễn ra hiện ở ngày hôm nay.
- Mặc định vị trí là công viên Đầm Sen (10.7632, 106.6355, xấp xỉ). Open-Meteo dùng lưới ~10 km nên sai số vài trăm mét không ảnh hưởng; sửa vĩ độ/kinh độ trong app nếu cần.
- Hướng gió là hướng gió thổi **từ** đâu (quy ước khí tượng, trùng cách gọi "gió Đông Nam"), chia 8 hướng. Nếu nguồn từ chối tham số hướng gió (HTTP 400), app lấy lại không có hướng gió và chỉ hiện tốc độ.
- Thời tiết: Open-Meteo (không cần khóa, chỉ dùng phi thương mại). AQI là mô hình ~45 km, không phải số liệu trạm đo. UV hiển thị là chỉ số cao nhất trong ngày (`uv_index_max`), nên ghi "UV đỉnh".
- Ngày/giờ hoàng đạo tính theo bảng lịch vạn niên phổ biến (12 thần); sách lịch có thể khác nhau ở một số cách chia. Tiết khí tính theo kinh độ Mặt Trời, ngày vào tiết theo UTC+7.
- Chưa chạy thử trên máy thật. Mã Kotlin/Java đã được biên dịch kiểm tra với Android API 33; tài nguyên và Gradle chỉ được xác nhận khi chạy workflow.

## Build bằng điện thoại (GitHub Actions)

Dùng chung repo đã có, không tạo repo mới.

1. Vào repo → **Add file → Upload files**, tải lên `lockscreen-widget.zip` (thư mục gốc repo). Tệp `.github/workflows/build-widget.yml` đã có từ trước, không đổi.
2. Tab **Actions → Build Clock Widget APK → Run workflow**.
3. Xong: tab **Releases** → bản `widget-N` → tải `ClockWidget.apk` và cài đè (cùng chữ ký nên giữ cấu hình).

Sau khi cài: gỡ widget cũ khỏi màn hình chính rồi thêm lại (kích thước mặc định đổi sang 4×3). Mở app một lần để cấp quyền Lịch. Cài đặt cũ giữ nguyên, riêng vị trí "Quận 11" mặc định được đổi sang Đầm Sen.

## Cài đặt trên HyperOS để chạy ổn định

- Cài đặt → Ứng dụng → Đồng hồ Lịch Thời tiết → **Tự khởi động**: Bật.
- Tiết kiệm pin: **Không hạn chế**.
- Khóa app trong màn hình đa nhiệm (nhấn giữ thẻ app → biểu tượng khóa).
- Thẻ khóa: Cài đặt → Thông báo → Màn hình khóa → hiện nội dung.
- Trong app có nút mở sẵn các màn hình trên.

## Cơ chế cập nhật

- **Tự động, tối thiểu mỗi giờ**: ba đường độc lập, đường nào chạy cũng đủ: (1) JobScheduler định kỳ 60 phút (job mới 7302, job 30 phút cũ bị hủy), (2) báo thức gần đúng ~60 phút tự đặt lại, (3) lệnh cập nhật định kỳ của widget (60 phút). Mỗi lần chạy lấy thời tiết nếu dữ liệu cũ hơn 45 phút (ngưỡng thấp hơn chu kỳ để hai đường lệch pha không bỏ qua nhau), rồi đọc lại lịch và vẽ lại. Android được phép dời các lịch này khi máy ngủ sâu, nên "mỗi giờ" là mục tiêu, không phải cam kết giây.
- **Chạm widget**: gửi lệnh làm mới ngay (bỏ qua ngưỡng 45 phút). Ngân sách thời gian 8 giây vì receiver bị hệ thống giới hạn ~10 giây; mạng chậm hơn thì giữ dữ liệu cũ. Bấm dồn trong lúc đang cập nhật bị bỏ qua. Mở app cũng làm mới nếu dữ liệu cũ.
- Dữ liệu lưu sẵn, mất mạng vẫn hiển thị (dòng địa điểm ghi giờ cập nhật nếu cũ hơn 90 phút). Chưa có dữ liệu thì ô thời tiết ghi "Chưa có dữ liệu · Chạm widget để cập nhật".
- Ngày/âm lịch/hoàng đạo/tiết khí: báo thức sau 00:00 mỗi ngày, cộng thêm khi đổi giờ, múi giờ, khởi động lại. Danh sách sự kiện được lọc lại theo giờ hiện tại lúc vẽ, nên sự kiện đã qua biến mất mà không cần đọc lại lịch.
- Mọi bước lập lịch và vẽ đều bọc try/catch riêng; vẽ widget luôn chạy trước bước lập lịch. Không dùng foreground service.

## Cấu trúc

- `LunarCalendar.java`: âm lịch (Hồ Ngọc Đức, UTC+7), can chi, 24 tiết khí. `VnText.java`: thứ, tháng, mô tả thời tiết, ngày lễ. `Almanac.java`: hoàng đạo/hắc đạo (12 thần), giờ hoàng đạo (chỉ dùng cho thẻ văn bản).
- `WeatherRepo.kt` (Open-Meteo, ngân sách thời gian, hướng gió), `CalendarRepo.kt` (CalendarContract), `Renderer.kt` (TextView/ImageView thuần, không vẽ chữ vào ảnh), `Updater.kt`, `Receivers.kt`, `LockCard.kt`, `LockWallpaper.kt`, `MainActivity.kt`, `Prefs.kt`, `App.kt` (di chuyển cài đặt từ bản cũ), `CrashLog.kt` (chỉ ghi logcat).
- `res/font`: TTF. `res/layout`: `w_*` (widget), `nb_*` (thẻ khóa mở rộng), `n_*` (thẻ thu gọn), `wp_*` (khối trên ảnh nền khóa), hậu tố `_l` = biến thể quầng sáng cho chữ tối; sinh theo từng bộ phông vì RemoteViews không đổi phông lúc chạy.
- `res/drawable`: `ic_wx_*` (9 biểu tượng thời tiết đơn sắc, tô theo màu chữ), `dot_red`/`dot_black` (viền trắng để chấm đen vẫn thấy trên nền tối), `pill` (ô nổi bật của thanh thứ), `divider`, `bg_r*`, icon app.
